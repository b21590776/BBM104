/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public interface PostInterface {
	
	/**
	 * @param T is new text post 
	 */
	public void setText(String T);
	
	/**
	 * @return	text of post
	 */
	public String getText();
	
	/**
	 * @return	id of post
	 */
	public String getID();
	
	/**
	 * @return	date of post
	 */
	public String getDate();
}
