import java.util.Date;
import java.util.LinkedList;
import java.util.UUID;
/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public abstract class Post implements PostInterface  {
	
	public Date postDate;
	public Location location;
	public String textContent;
	public final UUID id = UUID.randomUUID();
	public LinkedList<String> collectionOfTaggedFriend;
	
	
	
	/**
	 * @return	users of tagged on post
	 */
	public abstract String showTaggedUsers();
	
	/**
	 * @return	location of post 
	 */
	public abstract String showPostLocation();
}
