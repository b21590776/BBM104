/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class ImagePost extends TextPost{
	
	private String imageFileName;
	private String imageResolution;
	
	
	
	
	
	/**
	 * @param textContent	that is text content of image post
	 * @param longitude		that is longitude of image post
	 * @param latitude		that is latitude of image post
	 * @param userNames		that is userNames of image post
	 * @param filePath		that is file path of image post
	 * @param resolution	that is image resolution of image post
	 */
	public ImagePost(String textContent, String longitude, String latitude, String userNames, String filePath, String resolution) {
		super(textContent, longitude, latitude, userNames);
		this.imageFileName		= filePath;
		this.imageResolution	= resolution;
	}
	
	
	
	
	
	/**
	 * @return image file name of image post
	 */
	public String getImageFileName()	{		return "Image: " + imageFileName + "\n";					}
	/**
	 * @return image resolution of image post
	 */
	public String getImageResolution()	{		return"Image resolution: " + imageResolution + "\n";		}
	
	
	
	
	
	@Override
	public String toString() {
		String output = getText() + getDate() + showPostLocation() + getImageFileName() + getImageResolution() + showTaggedUsers();
		return output;
	}
}
