import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class TextPost extends Post{
	private SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
	
	/**
	 * @param textContent	that is text content of text post
	 * @param longitude		that is longitude of text post
	 * @param latitude		that is latitude of text post
	 * @param userNames		that is userNames of text post
	 */
	public TextPost(String textContent, String longitude, String latitude, String userNames) {
		this.postDate = new Date();
		
		this.location					= new Location(longitude, latitude);
		this.textContent				= textContent;
		this.collectionOfTaggedFriend	= new LinkedList<String>();
		
		
		for (int i = 0; i < userNames.split(":").length; i++){
			boolean isExistTagged = false;
			for (Users users : UsersCollection.sigInUser.getCollectionOfFriends()) {
				if(users.getUsername().equals(userNames.split(":")[i])){
					collectionOfTaggedFriend.add(userNames.split(":")[i]);
					isExistTagged = true;
				}
			}
			if(!isExistTagged){
				System.out.println("Username " + userNames.split(":")[i] + " is not your friend, and will not be tagged!");
			}
		}
	}
	
	
	
	
	
	@Override
	public String showTaggedUsers() {
		String output = "";
		if(collectionOfTaggedFriend.size() > 0){
			output = "Friends tagged in this post: ";
			
			int i = 0;
			for (String string : collectionOfTaggedFriend)
				for (Users users : UsersCollection.allUserList) 
					if(users.getUsername().equals(string)){
						i++;
						if(i == collectionOfTaggedFriend.size())
							output += users.getName();
						else
							output += users.getName() + " ,";
					}
						
		}
		return output;
	}
	
	
	
	
	
	@Override
	public String getID() 				{	return String.valueOf(id);							}
	@Override
	public String getText()				{	return textContent + "\n";							}
	@Override
	public String getDate()				{	return "Date: " + format.format(postDate) + "\n";	}
	@Override
	public void setText(String T)		{	textContent = T;									}
	@Override
	public String showPostLocation()	{	return location.toString();							}
	@Override
	public String toString() 			{	return getText() + getDate() +	showPostLocation() + showTaggedUsers();	}

}
