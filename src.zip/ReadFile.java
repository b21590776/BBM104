import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class ReadFile {
	
	private String[] lines;
	
	
	
	
	
	
	/**
	 * @param pathname that is file path of files
	 */
	public ReadFile(String pathname) {
		
		try {
			int i = 0;
			lines = new String[Files.readAllLines(Paths.get(pathname)).size()];
			for(String line: Files.readAllLines(Paths.get(pathname)))
				lines[i++] = line;
		} catch (IOException e){
			System.out.println("File could not be read!!!");
		} 
	}
	
	
	
	
	
	/**
	 * @return one dimension file array line by line
	 */
	public String[] getLines(){	return lines;	}
}
