import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedList;
/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class Users {
	
	private final int userID;
	private static int ID = 0;
	
	private String	name;
	private String	username;
	private String	password;
	private Date	dateOfBirth;
	private String	schoolGraduated;
	private Date	lastLogInDate;
	
	private LinkedList<Post> collectionPost;
	private ArrayList<Users> collectionOfFriends;
	private ArrayList<Users> collectionOfBlockedUsers;
	
	private SimpleDateFormat format1 = new SimpleDateFormat("dd/mm/yyyy");
	private SimpleDateFormat format2 = new SimpleDateFormat("mm/dd/yyyy");
	
	
	
	
	
	
	
	
	/**
	 * @param name				that is name of user
	 * @param userName			that is username of user
	 * @param password			that is password of user
	 * @param dateofBirth		that is date of birth of user
	 * @param schoolGraduated	that is school graduated of user
	 */
	public Users(String name, String userName, String password, String dateofBirth, String schoolGraduated) {
		
		try 						{	this.dateOfBirth	=	format1.parse(dateofBirth); } 
		catch (ParseException e)	{	e.printStackTrace();								}
		
		userID						=	++ID;
		this.name					=	name;
		this.username				=	userName;
		this.password				=	password;
		this.schoolGraduated		=	schoolGraduated;
		collectionPost 				= 	new LinkedList<Post>();
		collectionOfFriends 		= 	new ArrayList<Users>();
		collectionOfBlockedUsers 	= 	new ArrayList<Users>();
	}

	
	
	
	
	
	/**
	 * @return	userID	that is name of user
	 */
	public int getUserID()				{	return userID;							}
	/**
	 * @return name	that is name of user
	 */
	public String getName()				{	return name;							}
	/**
	 * @return userName	that is username of user
	 */
	public String getUsername()			{	return username;						}
	/**
	 * @return password	that is password of user
	 */
	public String getPassword()			{	return password;						}
	/**
	 * @return dateOfBirth that is date of birth of user
	 */
	public String getDateOfBirth()		{	return format2.format(dateOfBirth);		}
	/**
	 * @return lastLogInDate	that is last log in date of user
	 */
	public Date getLastLogInDate()		{	return lastLogInDate;					}
	/**
	 * @return schoolGraduated	that is school graduated of user 
	 */
	public String getSchoolGraduated()	{	return schoolGraduated;					}
	/**
	 * @return collectionPost {@link LinkedList}	that is collection of post of user 
	 */
	public LinkedList<Post> getCollectionPost() 			{	return collectionPost;					}
	/**
	 * @return collectionOfFriends {@link ArrayList}	that is collection of friends of user 
	 */
	public ArrayList<Users> getCollectionOfFriends()		{	return collectionOfFriends;				}
	/**
	 * @return collectionOfBlockedUsers {@link ArrayList} that is collection of blocked users of user
	 */
	public ArrayList<Users> getCollectionOfBlockedUsers()	{	return collectionOfBlockedUsers;		}
	/**
	 * current time equal lastLog in date
	 */
	public void setLastLogInDate()							{	this.lastLogInDate = new Date();		}
	/**
	 * @param name	that is name of user
	 */
	public void setName(String name)						{	this.name = name;						}
	/**
	 * @param password	that is password of user
	 */
	public void setPassword(String password)				{	this.password = password;				}
	/**
	 * @param schoolGraduated	that is school graduated of user
	 */
	public void setSchoolGraduated(String schoolGraduated)	{	this.schoolGraduated = schoolGraduated;	}
	/**
	 * @param dateOfBirth	that is date of birth of user
	 */
	public void setDateOfBirth(String dateOfBirth){	
		try 						{	this.dateOfBirth	=	format1.parse(dateOfBirth); } 
		catch (ParseException e)	{	e.printStackTrace();								}			
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void addPostText(String A){
		String textContent	= A.split("\t")[1];
		String longitude	= A.split("\t")[2];
		String latitude		= A.split("\t")[3];
		String userNames	= A.split("\t")[4];
		
		collectionPost.add(new TextPost(textContent, longitude, latitude, userNames));
		System.out.println("The post has been successfully added.");
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void addPostImage(String A){
		String textContent	= A.split("\t")[1];
		String longitude	= A.split("\t")[2];
		String latitude		= A.split("\t")[3];
		String userNames	= A.split("\t")[4];
		String filePath		= A.split("\t")[5];
		String resolution	= A.split("\t")[6];
		
		collectionPost.add(new ImagePost(textContent, longitude, latitude, userNames, filePath, resolution));
		System.out.println("The post has been successfully added.");
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void addPostVideo(String A){
		String textContent		= A.split("\t")[1];
		String longitude		= A.split("\t")[2];
		String latitude			= A.split("\t")[3];
		String userNames		= A.split("\t")[4];
		String filePath			= A.split("\t")[5];
		String videoDuration	= A.split("\t")[6];
		
		collectionPost.add(new VideoPost(textContent, longitude, latitude, userNames, filePath, videoDuration));
		System.out.println("The post has been successfully added.");
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void addFriend(String A){
		String userName = A.split("\t")[1];
		
		Users user = null;
		
		for (Users users : UsersCollection.allUserList)
			if(users.getUsername().equals(userName))
				user = users;
		
		if(user != null){
			if(UsersCollection.sigInUser.getCollectionOfFriends().contains(user)){
				System.out.println("This user is already in your friend list!");
			}
			else{
				UsersCollection.sigInUser.getCollectionOfFriends().add(user);
				System.out.println(userName + " has been successfully added to your friend list.");
			}
		}
		else{
			System.out.println("No such user!");
		}
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void blockUser(String A){
		String userName = A.split("\t")[1];
		
		Users user = null;
		
		for (Users users : UsersCollection.allUserList)
			if(users.getUsername().equals(userName))
				user = users;
		
		if(user != null){
			UsersCollection.sigInUser.getCollectionOfBlockedUsers().add(user);
			System.out.println(userName + " has been successfully blocked.");
		}
		else
			System.out.println("No such user!");
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void chPass(String A){
		String oldPassword = A.split("\t")[1];
		String newPassword = A.split("\t")[2];
		
		if(UsersCollection.sigInUser.getPassword().equals(oldPassword))
			UsersCollection.sigInUser.setPassword(newPassword);
		else																
			System.out.println("Password mismatch! Please, try again.");
	}
	
	
	
	
	
	/**
	 * this method do list all friends of sig in user
	 */
	public void listFriends(){
		for (Users users : UsersCollection.sigInUser.getCollectionOfFriends()) {
			System.out.println(users);
			System.out.println("---------------------------");
		}
		
		if(UsersCollection.sigInUser.getCollectionOfFriends().size() == 0)
			System.out.println("You haven\'t added any friends yet!");
	}
	
	
	
	
	
	/**
	 * this method do list all friends in system
	 */
	public void listUsers(){
		for (Users users : UsersCollection.allUserList) {
			System.out.println(users);
			System.out.println("---------------------------");
		}
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void removeFriend(String A){
		String userName = A.split("\t")[1];
		
		Users user = null;
		
		for (Users users : UsersCollection.sigInUser.getCollectionOfFriends()) 
			if(users.getUsername().equals(userName))
				user = users;
		
		if(user != null){
			UsersCollection.sigInUser.getCollectionOfFriends().remove(user);
			System.out.println(userName + " has been successfully removed from your friend list.");
		}
		else
			System.out.println("No such friend!");
	}
	
	
	
	
	
	/**
	 * this method removes last post of sign in user
	 */
	public void removeLastPost(){
		if(UsersCollection.sigInUser.getCollectionPost().size() > 0){
			UsersCollection.sigInUser.getCollectionPost().removeLast();
			System.out.println("Your last post has been successfully removed.");
		}
		else{
			System.out.println("Error: You don\'t have any posts.");
		}
	}
	
	
	
	
	
	/**
	 * this method shows blocked users of sig in user
	 */
	public void showBlockedUsers(){
		for (Users users : UsersCollection.sigInUser.getCollectionOfBlockedUsers()) {
			System.out.println(users);
			System.out.println("---------------------------");
		}
	}
	
	
	
	
	
	/**
	 * this method shows blocked friends users of sig in user
	 */
	public void showBlockedFriends(){
		boolean isFriend = false;
		
		for (Users users1 : UsersCollection.sigInUser.getCollectionOfBlockedUsers()) {
			for (Users users2 : UsersCollection.sigInUser.getCollectionOfFriends()) {
				if(users1 == users2){
					System.out.println(users1);
					System.out.println("---------------------------");
					isFriend = true;
				}
			}
		}
		
		if(isFriend == false)
			System.out.println("You haven\'t blocked any friends yet!");
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void unBlockUser(String A){
		String userName = A.split("\t")[1];
		
		Users user = null;
		
		for (Users users : UsersCollection.sigInUser.getCollectionOfBlockedUsers())
			if(users.getUsername().equals(userName))
				user = users;
		
		if(user != null){
			UsersCollection.sigInUser.getCollectionOfBlockedUsers().remove(user);
			System.out.println(userName + " has been successfully unblocked.");
		}
		else{
			System.out.println("No such user in your blocked users list!");
		}
	}
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public void updateProfil(String A){
		String name				=	A.split("\t")[1];
		String dateOfBirth		=	A.split("\t")[2];
		String schoolGraduated	=	A.split("\t")[3];
		
		UsersCollection.sigInUser.setName(name);
		UsersCollection.sigInUser.setDateOfBirth(dateOfBirth);
		UsersCollection.sigInUser.setSchoolGraduated(schoolGraduated);
	}
	
	
	
	
	
	@Override
	public String toString() {
		String output = "Name: "			+ getName()			+ "\n"	+
						"Username: "		+ getUsername()		+ "\n" + 
						"Date of Birth: "	+ getDateOfBirth()	+ "\n" + 
						"School: "			+ getSchoolGraduated();
		return output;
	}
}
