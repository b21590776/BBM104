/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class Main {

	/**
	 * @param args are file names user and commands
	 */
	public static void main(String[] args) {
		
		
		ReadFile users 		= new ReadFile(args[0]);
		ReadFile commands 	= new ReadFile(args[1]);
		
		UsersCollection.addUsers(users.getLines());
		
		
		for (int i = 0; i < commands.getLines().length; i++) {
			System.out.println("-----------------------\nCommand: " + commands.getLines()[i]);
			
			if(commands.getLines()[i].split("\t")[0].equals("ADDUSER"))
				UsersCollection.addUser(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("REMOVEUSER"))
				UsersCollection.removeUser(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("SHOWPOSTS"))
				UsersCollection.showPost(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("SIGNIN"))
				UsersCollection.signIn(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("SIGNOUT"))
				UsersCollection.signOut();
			
			else if(commands.getLines()[i].split("\t")[0].equals("UPDATEPROFILE"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.updateProfil(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("CHPASS"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.chPass(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("ADDFRIEND"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.addFriend(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("REMOVEFRIEND"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.removeFriend(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("ADDPOST-TEXT"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.addPostText(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("ADDPOST-IMAGE"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.addPostImage(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("ADDPOST-VIDEO"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.addPostVideo(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("REMOVELASTPOST"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.removeLastPost();
			else if(commands.getLines()[i].split("\t")[0].equals("BLOCK"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.blockUser(commands.getLines()[i]);
			else if(commands.getLines()[i].split("\t")[0].equals("UNBLOCK"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.unBlockUser(commands.getLines()[i]);								
			else if(commands.getLines()[i].split("\t")[0].equals("LISTFRIENDS"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.listFriends();
			else if(commands.getLines()[i].split("\t")[0].equals("LISTUSERS"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.listUsers();
			else if(commands.getLines()[i].split("\t")[0].equals("SHOWBLOCKEDFRIENDS"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.showBlockedFriends();
			else if(commands.getLines()[i].split("\t")[0].equals("SHOWBLOCKEDUSERS"))
				if(UsersCollection.sigInUser == null)		System.out.println("Error: Please sign in and try again.");
				else										UsersCollection.sigInUser.showBlockedUsers();
		}
	}
}
