import java.util.ArrayList;
/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class UsersCollection {
	
	public static Users sigInUser = null;
	public static ArrayList<Users> allUserList = new ArrayList<Users>();
	
	
	
	
	
	/**
	 * @param A	is a line of command file
	 */
	public static void addUser(String A){
		String name				= A.split("\t")[1];
		String userName			= A.split("\t")[2];
		String password			= A.split("\t")[3];
		String dateofBirth		= A.split("\t")[4];
		String schoolGraduated	= A.split("\t")[5];	
		
		UsersCollection.allUserList.add(new Users( name,  userName,  password,  dateofBirth,  schoolGraduated));
		
		System.out.println(name + " has been successfully added.");
	}
	
	
	
	
	
	/** 
	 * @param A	is a line of command file
	 */
	public static void addUsers(String[] A){
		for (int i = 0; i < A.length; i++){
			String name				= A[i].split("\t")[0];
			String userName			= A[i].split("\t")[1];
			String password			= A[i].split("\t")[2];
			String dateofBirth		= A[i].split("\t")[3];
			String schoolGraduated	= A[i].split("\t")[4];
			
			UsersCollection.allUserList.add(new Users(name, userName, password, dateofBirth, schoolGraduated));
		}
	}
	
	
	
	
	
	/** 
	 * @param A	is a line of command file
	 * @return boolean value 
	 */
	public static boolean removeUser(String A){
		Integer	userID	= Integer.parseInt(A.split("\t")[1]);
		Users	user	= null;
		
		for (Users users : allUserList)
			if(users.getUserID() == userID)
				user = users;
		
		if(user != null){
			UsersCollection.allUserList.remove(user);
			System.out.println("User has been successfully removed.");
			return true;
		}
		System.out.println("No such user!");
		return false;
	}
	
	
	
	
	
	/** 
	 * @param A	is a line of command file
	 */
	public static void showPost(String A){
		String	userName	= A.split("\t")[1];
		Users	user		= null; 
		
		for (Users users : UsersCollection.allUserList)
			if(users.getUsername().equals(userName))
				user = users;
		
		if(user != null){
			if(user.getCollectionPost().size() > 0){
				System.out.println("**************\n" + userName + "\'s Posts\n**************");
				for (Post post : user.getCollectionPost()) {
					System.out.println(post);
					System.out.println("----------------------");
				}
			}
			else
				System.out.println(userName + " does not have any posts yet.");
		}
		else
			System.out.println("No such user!");
	}
	
	
	
	
	
	/** 
	 * @param A	is a line of command file
	 */
	public static void signIn(String A){
		String userName	= A.split("\t")[1];
		String password	= A.split("\t")[2];
		
		Users user = null;
		
		for (Users users : allUserList)
			if(users.getUsername().equals(userName))
				user = users;
		
		if(user != null){
			if(user.getPassword().equals(password)){
				System.out.println("You have succesfully signed in.");
				UsersCollection.sigInUser = user;
				UsersCollection.sigInUser.setLastLogInDate();
			}
			else{
				System.out.println("Invalid username or password! Please try again.");
				sigInUser =  null;
			}
		}
		else{
			System.out.println("No such user!");
			sigInUser =  null;
		}
	}
	
	
	
	
	
	/**
	 *  This method out of sigin
	 */
	public static void signOut(){
		sigInUser = null;
		System.out.println("You have succesfully signed out.");
	}
}
