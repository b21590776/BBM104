/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class VideoPost extends TextPost {
	
	private int videoDuration;
	private String videoFileName;
	public final int maximumVideoLength = 10;
	
	
	
	
	
	/**
	 * @param textContent	that is text content of video post
	 * @param longitude		that is longitude of video post
	 * @param latitude		that is latitude of video post
	 * @param usersName		that is usersName of video post
	 * @param filePath		that is file path of video post
	 * @param videoDuration	that is video duration of video post
	 */
	public VideoPost(String textContent, String longitude, String latitude, String usersName, String filePath, String videoDuration) {
		super(textContent, longitude, latitude, usersName);
		this.videoFileName	= filePath;
		this.videoDuration	= Integer.parseInt(videoDuration);
	}
	
	
	
	
	
	/**
	 * @return	video duration of video post
	 */
	public String getVideoDuration()	{	return "Video duration: " + videoDuration + " minutes\n";	}
	/**
	 * @return	video file name of video post
	 */
	public String getVideoFileName()	{	return "Video: " + videoFileName + "\n";					}
	
	
	
	
	
	@Override
	public String toString() {
		return getText() + getDate() + showPostLocation() + getVideoFileName() + getVideoDuration() + showTaggedUsers();
	}
}
