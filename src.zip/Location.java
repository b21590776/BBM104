/**
 * @author		EGE BERKE BALSEVEN
 * @since		28/04/2017
 * @version		v.0.0.1
 */
public class Location {
	private double latitude;
	private double longitude;
	
	
	
	
	/**
	 * @param longitude	that is longitude of post
	 * @param latitude	that is latitude of post
	 */
	public Location(String longitude, String latitude) {
		this.latitude	= Double.parseDouble(latitude);
		this.longitude	= Double.parseDouble(longitude);
	}
	
	
	
	
	/**
	 * @return	latitude of post location 
	 */
	public double getLatitude()		{	return latitude;	}
	/**
	 * @return	longitude of post location
	 */
	public double getLongitude()	{	return longitude;	}
	
	
	
	
	
	/**
	 * @param latitude	that is latitude of post
	 */
	public void setLatitude(double latitude)	{	this.latitude = latitude;	}
	/**
	 * @param longitude	that is longitude of post
	 */
	public void setLongitude(double longitude)	{	this.longitude = longitude;	}
	
	
	
	
	
	@Override
	public String toString() {
		String out = "Location: " + getLongitude() + ", " + getLatitude() + "\n";
		return out;
	}
}
